layui.define(function(exports) {

    var kitconfig = {
        resourcePath: './build/', //框架资源路径-相对路径和绝对路径
    };

    exports('kitconfig', kitconfig);
});